import pygame
import tools
import data
import sys
import socket
import re
from misc import Settings
from misc import Connection
def get_ret():
    while True:
        ret=conn.recv()
        if ret!="":
            if ret[0]==c:
                return ret
tools.game_initialize()
settings=Settings()
#ip=tools.LoginPage()
#settings.change_ip(ip)
#print(ip)
screen = pygame.display.set_mode((1280, 720))
background = pygame.image.load("./graph/bg.jpg")
screen.blit(background, (0, 0))
pygame.display.update()
click = [0]*30 #存储记录手牌是否被点击
play0=[]
myclock = 1
myturn = 1
flag=1
conn=Connection(settings.HOST)
while not conn.connected:
    conn.connect()
conn.send_info(settings)
while True:
    ret=conn.recv()
    if ret[0]=='check_alive':
        conn.check_alive()
    elif ret[0]=='are_you_ready':
        conn.ready()
        ret=conn.recv()
        if ret[0]=='game_restart':
            continue
        elif ret[0]=='player_info':
            break
name0='player';coin0='3000'
name1=ret[1][0];coin1=ret[1][1]
name2=ret[1][2];coin2=ret[1][3]
myfont=pygame.font.SysFont('arial',40,1)
name0Image=myfont.render(name0, True,data.white)
name1Image=myfont.render(name1, True,data.white)
name2Image=myfont.render(name2, True,data.white)
coin0Image=myfont.render(coin0, True,data.white)
coin1Image=myfont.render(coin1, True,data.white)
coin2Image=myfont.render(coin2, True,data.white)

msg=conn.recv()
print(msg)
hand=msg[1]
hand.sort(key=tools.cardsort,reverse=True)
bgm_flag=1

while 1:
    tools.screen.blit(tools.background,(0,0))#打印背景
    
    screen.blit(name0Image,(0,0))                #打印对手的牌
    screen.blit(name1Image,(600,0))
    screen.blit(name2Image,(1200,0))
    screen.blit(coin0Image,(0,100))
    screen.blit(coin1Image,(600,100))
    screen.blit(coin2Image,(1200,100))

    
    hand,myturn,click,play0=tools.detect_keyboard_mouse(hand,myturn,click,conn,play0)
    tools.print_card(hand,click,play0)#打印手牌
    myclock = tools.print_buttons(myclock,myturn) #传入myclock
    if bgm_flag:
        tools.bgm_judge(len(hand))
    pygame.display.update()

