card_width=95
card_height=146 #卡牌的大小
card_x=(1280-19*card_width/2-card_width)/2
card_y=720-card_height*4/3  #卡牌的位置
clock_y=720-card_height*2-4  #钟的y坐标
#字体颜色
brown=(245,97,37)
white=(255,255,255)
