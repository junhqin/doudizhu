import pygame
from pygame.locals import *
from sys import exit
 
pygame.init()
size=width,height=1280,720
screen=pygame.display.set_mode(size)
# screen = pygame.display.set_mode(window_size, 0, 32)
pygame.display.set_caption('斗地主')
icon=pygame.image.load("./graph/窗口.jpg")
start_button = pygame.image.load("./graph/开始游戏.png")
pygame.display.set_icon(icon)#设置窗口图片
myfont=pygame.font.SysFont('arial',40,1)
def LoginPage():
    message_box = []  # Create a message box
    back_image = pygame.image.load('./graph/界面.jpg')
    while True:
        break_switch = False
        for event in pygame.event.get():
            if event.type == QUIT:
                exit()
            pygame.display.flip()
            screen.blit(start_button,(470, 370, 300, 50))    
            screen.fill((255, 255, 255))        
            screen.blit(back_image, (400, 100))
            # message box .....................................................................
            screen.set_clip(470, 300, 300, 50) 
            screen.fill((255, 255, 255)) 
            x, y = pygame.mouse.get_pos()
            if 500 < x < 800 and 300 < y < 350:
                # print('mouse in the box')
                if event.type == KEYDOWN:
                    key_num = event.key
                    # print(key_num)
                    if key_num == 49:
                        message_box.append('1') # get the value 
                    elif key_num == 50:
                        message_box.append('2') 
                    elif key_num == 51:
                        message_box.append('3') 
                    elif key_num == 52:
                        message_box.append('4')
                    elif key_num == 53:
                        message_box.append('5')
                    elif key_num == 54:
                        message_box.append('6')  
                    elif key_num == 55:
                        message_box.append('7')  
                    elif key_num == 56:
                        message_box.append('8') 
                    elif key_num == 57:
                        message_box.append('9')  
                    elif key_num == 48:
                        message_box.append('0')  
                    elif key_num == 46:
                        message_box.append('.')  
                    elif key_num == 8 and len(message_box) is not 0:
                        message_box.pop()  # delete the last value
 
            text = ''.join(message_box)  
            font_family = pygame.font.SysFont('arial', 26) 
            IP_name = ' IP: '
            screen.blit(font_family.render(IP_name, True, (0, 0, 0)), (480, 310))
            screen.blit(font_family.render(text, True, (0, 0, 0)), (560, 310))
            # 登录按钮 ...................................................................

            screen.blit(start_button,(470, 370, 300, 50))  # 登录按钮位置
            # screen.fill((47, 79, 79))  # submit button's color
            Login_name = 'Login'
            screen.blit(font_family.render(Login_name, True, (255, 255, 255)), (585, 380))
            if 470 < x < 770 and 370 < y < 420 and event.type == MOUSEBUTTONDOWN:
                screen.set_clip(470, 370, 300, 50)  # 登录按钮位置
                print(text)
                break_switch = True
        pygame.display.update()
        if break_switch :
            print('break')
            break
 
if __name__ == '__main__':
    LoginPage()
