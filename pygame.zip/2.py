def cardsort(card):
    c=int(L[card],16)     #16进制
    if c==16:return 999
    if c==32:return 1000
    cpower=c//16
    ctype=c%16
    return cpower*16+(5-ctype)
import sys
import pygame
import time
import random

#初始化
pygame.init()
pygame.mixer.init()
pygame.mixer.music.load("./music/bgm.mp3")
pygame.mixer.music.play(-1,0)
screen = pygame.display.set_mode((1280, 720))
bg=pygame.image.load("./graph/bg.jpg")
screen.blit(bg,(0,0))
clock=pygame.image.load("./graph/clock.png")
clockrect=clock.get_rect()
myfont=pygame.font.SysFont('arial',40,1)
start=time.time()

#参数
w=95;h=146  #单张牌长宽
a=(1280-19*w/2-w)/2;b=720-h*4/3  #第一张牌坐标
left=a;height=b  #左边预留宽度、下方预留宽度
brown=(245,97,37)

#初始化手牌
hand=[]
rand=random.randint(0,53)
for i in range(20):
    while rand in hand:
        rand=random.randint(0,53)
    hand.append(rand)
print(hand)
L=["10","20","31","41","51","61","71","81","91","a1","b1","c1","d1","e1","f1",\
             "32","42","52","62","72","82","92","a2","b2","c2","d2","e2","f2",\
             "33","43","53","63","73","83","93","a3","b3","c3","d3","e3","f3",\
             "34","44","54","64","74","84","94","a4","b4","c4","d4","e4","f4"]
hand.sort(key=cardsort,reverse=True)
cli=[0]*30

'''s=pygame.mixer.Sound("./music/win.mp3")
s.play()'''


while 1:
    screen.blit(bg,(0,0))

    #显示手牌
    for i in range(len(hand)):
        card=pygame.image.load("./card/"+L[hand[i]]+".png")
        card1=pygame.image.load("./card/"+L[hand[i]]+"l.png")
        if cli[i]:b-=h/5
        screen.blit(card,(a,b))
        screen.blit(card1,(a,b-100))
        a+=w/2
        b=720-h*4/3 
    a=(1280-19*w/2-w)/2   
    #time.sleep(0.15)

    #显示时钟
    screen.blit(clock,((1280-clockrect.width)/2,720-h*2.15))
    tim=str(30-int(time.time()-start))
    timImage=myfont.render(tim,True,brown)
    timrect=timImage.get_rect()
    screen.blit(timImage,((1280-timrect.width)/2+1,720-h*2-4))

    #检测键鼠
    for event in pygame.event.get():
         if event.type==pygame.KEYDOWN:
            if event.key==pygame.K_ESCAPE:#退出ESC
                pygame.quit()
                sys.exit()
         elif event.type == pygame.MOUSEBUTTONDOWN:#检测点击
            x,y=pygame.mouse.get_pos()
            if (720-h/3)>=y and y>=(720-h*4/3):
                num=int((x-left)/(w/2))
                cli[num]=1-cli[num]
            #print(x,y)
                
            '''x,y=pygame.mouse.get_pos()
            if x<=100 and y<=200:
                    a+=w/2
                    name=hex(int(name,16)+1).lstrip("0x")'''
    
    pygame.display.update()
