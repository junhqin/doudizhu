import random
import pygame
import time
import data
import sys
global myclock
import os
import re
from misc import Settings
from pygame.locals import *
#牌堆
card_pile=["10","20","31","41","51","61","71","81","91","a1","b1","c1","d1","e1","f1",\
             "32","42","52","62","72","82","92","a2","b2","c2","d2","e2","f2",\
             "33","43","53","63","73","83","93","a3","b3","c3","d3","e3","f3",\
             "34","44","54","64","74","84","94","a4","b4","c4","d4","e4","f4"]
#对存储牌的列表进行排序
click = [0]*30 #存储记录手牌是否被点击
def cardsort(card):
    c=int(card,16)
    if c==16:return 999
    if c==32:return 1000
    cpower=c//16
    ctype=c%16
    return cpower*16+(5-ctype)
#游戏初始化
def game_initialize():
    global clock
    global clockrect
    global background
    global myfont
    global screen
    global myturn
    global buttonchu
    global buttonpass
    global passrect
    global myclock
    global settings
    global start_button
    myturn = 1 
    pygame.init()
    pygame.mixer.init()
    pygame.mixer.music.load("./music/bgm.mp3")
    pygame.mixer.music.play(-1, 0)
    screen = pygame.display.set_mode((1280, 720))
    pygame.display.set_caption('斗地主')
    icon=pygame.image.load("./graph/窗口.jpg")
    start_button = pygame.image.load("./graph/开始游戏.png")
    pygame.display.set_icon(icon)#设置窗口图片
    myfont=pygame.font.SysFont('arial',40,1)
    tubiao=pygame.image.load("./graph/图标.png")
    background = pygame.image.load("./graph/bg.jpg")
    screen.blit(background, (0, 0))
    clock = pygame.image.load("./graph/clock.png")
    clockrect = clock.get_rect()
    buttonpass = pygame.image.load("./graph/pass.png")
    passrect = buttonpass.get_rect()
    buttonchu = pygame.image.load("./graph/chu.png")
    myclock = 1
    
    rect = tubiao.get_rect()
    screen_rect = screen.get_rect()
    rect.midtop = screen_rect.midtop
    screen.blit(tubiao,rect) 
    tip = pygame.image.load("./graph/tip.jpg")
    screen.blit(tip,(100,620-64))
    pygame.display.update()
    #由服务端给出具体状况

def print_card(hand,click,play0):#打印手牌
    card_x = (1280 - 19 * data.card_width / 2 - data.card_width) / 2
    card_y = 720 - data.card_height * 4 / 3
    for i in range(len(hand)):
        card=pygame.image.load("./card/"+hand[i]+".png")
        if click[i]:card_y-=data.card_height/5
        screen.blit(card,(card_x,card_y))
        card_x+=data.card_width/2
        card_y = 720 - data.card_height * 4 / 3
    for i in range(len(play0)):
        cardl=pygame.image.load("./card/"+play0[i]+"l.png")
        screen.blit(cardl,((1280-(len(play0)-1)*57/2-57)/2+i*57/2,data.clock_y-20))

    back=pygame.image.load("./card/back.png")
    backrect=back.get_rect()
    screen.blit(back,(95*1,(720-146)/2-73))    
    screen.blit(back,(1280-95-95*1,(720-146)/2-73))
    
    num1='17';num2='17'
    num1Image = myfont.render(num1, True,data.white)
    num2Image = myfont.render(num2, True,data.white)
    numrect = num1Image.get_rect()
    screen.blit(num1Image,(95+backrect.width/2-numrect.width/2,\
                           (720-146)/2+backrect.height/2-numrect.height/2-73))
    screen.blit(num1Image,(1280-95-95*1+backrect.width/2-numrect.\
                           width/2,(720-146)/2+backrect.height/2-numrect.height/2-73))
    
    
def detect_keyboard_mouse(hand,myturn,click,conn,play0):
    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:  # 退出ESC
                pygame.quit()
                sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:  # 检测点击
            x, y = pygame.mouse.get_pos()#鼠标点击位置
            if (720 - data.card_height / 3) >= y and y >= (720 - data.card_height * 4 / 3):
                num = int((x - data.card_x) / (data.card_width / 2))
                click[num] = 1 - click[num]
                #音乐播放
                music_click = pygame.mixer.Sound("./music/click.mp3")
                music_click.play()
            elif myturn \
                 and 1280 / 2 + clockrect.width <= x <= 1280 / 2 + clockrect.width + passrect.width \
                 and data.clock_y + clockrect.height - passrect.height - 15 <= y <= data.clock_y + clockrect.height - 15:
                 music = pygame.mixer.Sound("./music/button.mp3")
                 music.play()
                 play0=[];play1=[]
                 for k in range(len(hand)):
                     if click[k]:
                         play0+=[hand[k]]
                         play1+=[int(hand[k][0],16)]
                 play1.reverse()
                 if judge_card_pattern(play1):
                     myturn = 0
                     k=0
                     while k < len(hand):
                         if click[k]:
                             hand.remove(hand[k])
                             click.remove(click[k])
                         else:
                             k += 1
                     conn.play_cards(play0)
                     print(judge_card_pattern(play1))
                     p='./music/'
                     for i in range(len(play1)):
                         p+=str(play1[i])
                     p+='.mp3'
                     if(os.path.isfile(p)):
                         if '20' not in hand and p=='./music/1.mp3':
                             music = pygame.mixer.Sound('./music/-1.mp3')
                             music.play()
                         elif p=='./music/12.mp3' and len(play1)==2:
                             music = pygame.mixer.Sound('./music/-2.mp3')
                             music.play()
                         else:
                             music = pygame.mixer.Sound(p)
                             music.play()
                 else:
                    print(play1)
                    for i in range(len(click)):
                        click[i]=0
                        play0=[]
                    
            elif myturn \
                 and 1280 / 2 - clockrect.width - passrect.width <= x <= 1280 / 2 - clockrect.width \
                 and data.clock_y + clockrect.height - passrect.height - 15 <= y <= data.clock_y + clockrect.height - 15:
                 music = pygame.mixer.Sound("./music/button.mp3")
                 music.play()
                 myturn = 0
                 play0=[]
                 conn.play_cards([])
    return hand,myturn,click,play0

def print_buttons(myclock,myturn):
    if myturn:
        global start_time
        if myclock:
             start_time = time.time()
             myclock = 0
        screen.blit(clock, ((1280 - clockrect.width) / 2, 720 - data.card_height* 2.15))
        tim = str(30 - int(time.time() - start_time))
        timImage = myfont.render(tim, True,data.brown)
        timrect = timImage.get_rect()
        screen.blit(timImage, ((1280 - timrect.width) / 2 + 1, data.clock_y))
        screen.blit(buttonpass, (1280 / 2 - clockrect.width - passrect.width, \
                                 data.clock_y + clockrect.height - passrect.height - 15))
        screen.blit(buttonchu, (1280 / 2 + clockrect.width, \
                                data.clock_y + clockrect.height - passrect.height - 15))
    return myclock
def bgm_judge(x):
    if x<=2:
        pygame.mixer.music.load("./music/bgm.mp3")
        pygame.mixer.music.play(-1, 0)
def judge_card_pattern(play):
    length = len(play)
    if length == 1:return 1 #单牌

    if (length == 2) and (play[0] ==play[1]):return 2 #对子

    if length == 2 and (play[0] ==1 and play[1] == 2 ):return -1 #王炸

    if length == 3and play[0] == play[1] and play[1] == play[2]:return 3 #三个

    if length == 4:
        if (judge_card_pattern(play[0:3])==3 or judge_card_pattern(play[1:4])==3 ):
            if play[3]!=play[0]: return 3
            else:return -1#炸弹

    if length > 4:
        flag = 0
        for i in range(length-1):
            if play[i]==play[i+1]:
                flag = 1
                break
        if not flag:
            if play[length-1] - play[0]+1 == length and play [length-1]!=15:
                return 5#单个牌顺子
        else:#不是单个牌顺子
            if length == 5:
                if (judge_card_pattern(play[0:3])==3 and judge_card_pattern(play[3:5])==2) or \
                        (judge_card_pattern(play[2:5])==3 and judge_card_pattern(play[0:2])==2):
                   return 3 #三带一对
            if length ==6:
                    if judge_card_pattern(play[0:4])==-1 or judge_card_pattern(play[2:6])==-1or judge_card_pattern(play[1:5])==-1 :
                        return 10#炸弹带一对
            if length%3 ==0:
                flag = 1
                for i in range(0,length-2,3):
                    if(judge_card_pattern(play[i:i+3])!=3):
                        flag = 0
                        break
                if  flag:
                    flag_ = 1
                    for i in range(0, length - 5,3):
                        if play[i] != play[i + 3]-1:
                            flag_ = 0
                    if flag_:
                      return 6#不带翅膀的飞机
                    else:
                        return 0
            if length%2 == 0:
                flag1=0
                for i in range(0,length - 1,2):
                    if(judge_card_pattern(play[i:i+2])!=2):
                          flag1 = 1
                          break
                if not flag1:
                    flag2 = 1
                    for i in range(0,length-3,2):
                        if play[i] != play[i+2]-1:
                            flag2 = 0
                            break
                    if flag2:
                       return 7#连对
            if length >= 7:
                m = find_triple(play)
                for i in range(length - 3*m):
                    if (judge_card_pattern(play[i:i+3*m])==6):##问题1：找一个函数返回其中相等个数为三个的数字个数
                            flag_1 = 1
                            flag_2 = 1
                            if (length - 3*m)//2 <= m:
                                if ((i %2 == 0)and ((length - i - 3*m)%2==0)):
                                    for a in range(i//2):
                                        if (judge_card_pattern(play[2*a:2*a+2])!=2):
                                            flag_2 = 0
                                            break
                                        if (play[2*a]==play[2*a+2]):
                                            flag_2 = 0
                                            break
                                    for a in range(length-1,3*m+i,-2):
                                        if (judge_card_pattern(play[a:a - 2]) != 2):
                                            flag_2 = 0
                                            break
                                        if (play[a] == play[a - 2]):
                                            flag_2 = 0
                                            break
                                elif((i%2 == 1 and (length-i-3*m)%2 == 1)\
                                        or (i%2 == 1 and (length-i-3*m)%2 ==0)\
                                        or (i%2 == 0 and (length-i-3*m)%2 ==1)):
                                    flag_2 = 0
                                    if (length - 3*m - i)>m:
                                        flag_1 = 0
                                    for p1 in range(i):
                                        if (p1+1<i and play[p1]==play[p1+1]):
                                            flag_1 = 0
                                            break
                                    for p2 in range(i+3*m-1,length,1):
                                        if (p2+1<length and play[p2]==play[p2+1]):
                                            flag_1 = 0
                                            break
                            else:
                                flag_1 =0
                                flag_2 = 0
                            if (flag_1):return 9 #飞机带单牌
                            if (flag_2):return 8 #飞机带对子
    return 0 #所有类型都不是#
def find_triple(L1):
    L = L1 +[999]
    last = L[0]
    count = 1
    num = 0
    for i in range(1,len(L)-1):
        if (L[i] == last):
           count +=1
           if count == 3 :
               if L[i+1] != last:
                    i+=1
                    num+=1
                    count = 1
               else:
                   i+=1
                   count = 0
        else:
            last = L[i]
            count = 1
    return num
def LoginPage():
    message_box = []  # Create a message box
    while True:
        break_switch = False
        for event in pygame.event.get():
            if event.type == QUIT:
                exit()
            pygame.display.flip()
            screen.blit(start_button,(470, 370))    
        
            # screen.blit(bg, (400, 100))
            # message box .....................................................................
            screen.set_clip(470, 300, 300, 50) 
            screen.fill((255, 255, 255)) 
            x, y = pygame.mouse.get_pos()
            if 500 < x < 800 and 300 < y < 350:
                # print('mouse in the box')
                if event.type == KEYDOWN:
                    key_num = event.key
                    # print(key_num)
                    if key_num == 49:
                        message_box.append('1') # get the value 
                    elif key_num == 50:
                        message_box.append('2') 
                    elif key_num == 51:
                        message_box.append('3') 
                    elif key_num == 52:
                        message_box.append('4')
                    elif key_num == 53:
                        message_box.append('5')
                    elif key_num == 54:
                        message_box.append('6')  
                    elif key_num == 55:
                        message_box.append('7')  
                    elif key_num == 56:
                        message_box.append('8') 
                    elif key_num == 57:
                        message_box.append('9')  
                    elif key_num == 48:
                        message_box.append('0')  
                    elif key_num == 46:
                        message_box.append('.')  
                    elif key_num == 8 and len(message_box)!= 0:
                        message_box.pop()  # delete the last value
 
            text = ''.join(message_box)  
            font_family = pygame.font.SysFont('arial', 26) 
            IP_name = ' IP: '
            screen.blit(font_family.render(IP_name, True, (0, 0, 0)), (480, 310))
            screen.blit(font_family.render(text, True, (0, 0, 0)), (560, 310))
            # 登录按钮 ...................................................................

            screen.blit(start_button,(470, 370, 300, 50))  # 登录按钮位置
            # screen.fill((47, 79, 79))  # submit button's color
            Login_name = 'Login'
            screen.blit(font_family.render(Login_name, True, (255, 255, 255)), (585, 380))
            if 470 < x < 770 and 370 < y < 470 and event.type == MOUSEBUTTONDOWN:
                screen.set_clip(470, 370, 300, 50)  # 登录按钮位置
                break_switch = True
        pygame.display.update()
        if break_switch :
            break
    return text
