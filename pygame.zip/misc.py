import socket
import re
import os

class Settings:

    name=""
    coin=1000
    music=1
    sound_effects=1
    filepath="gamedata.txt"

    HOST=""
    info=[""]

    hasName=False
    hasHost=False

    def __init__(self):
        if os.path.isfile(self.filepath):
            self.file=open(self.filepath,"r")
            info=self.file.readline().split(',')
            self.file.close()
            if info!=[""]:
                try:
                    if len(info[0])<=32:
                        self.name=info[0]
                        self.hasName=True
                    self.coin=int(info[1])
                    self.music=int(info[3])
                    self.sound_effects=int(info[4])
                    if self.check_ip(info[2])!=-1:
                        self.HOST=self.check_ip(info[2])
                        self.hasHost=True
                except:
                    pass
        else:
            self.save_data()
    
    def check(self):
        return self.hasName,self.hasHost

    def change_name(self,newname:str) -> bool:
        if isinstance(newname,str) and len(newname)<=32 and not ("," in newname):
            self.name=newname
            self.hasName=True
            self.save_data()
            return True
        else:
            return False
    
    def change_coin(self,value:int) -> int:
        if not isinstance(value,int):
            raise ValueError
        self.coin=self.coin+value
        self.save_data()
        return self.coin

    def change_music(self):
        self.music=1-self.music
        self.save_data()
        return self.music

    def change_sfx(self):
        self.sound_effects=1-self.sound_effects
        self.save_data()
        return self.sound_effects

    def change_ip(self,ip_addr):
        ip_addr=self.check_ip(ip_addr)
        if ip_addr!=-1:
            self.HOST=ip_addr
            self.hasHost=True
            self.save_data()
            return ip_addr
        else:
            return -1

    def check_ip(self,ip_addr):
        if ip_addr.isdigit():
            if int(ip_addr)>=0 and int(ip_addr)<=255:
                return "192.168.1." + ip_addr
        if None == re.fullmatch(r'((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3}',ip_addr):
            return -1
        return ip_addr

    def save_data(self):
        file=open(self.filepath,"w")
        file.write(f"{self.name},{self.coin},{self.HOST},{self.music},{self.sound_effects}")

class Connection:

    HOST=""
    PORT=65535

    connected=False

    conn=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

    def __init__(self,host):
        self.HOST=host
        self.conn.setblocking(True)
    
    def change_host(self,newhost:str) -> bool:
        if self.connected==True:
            raise ConnectionError("Already connected.")
        newhost=Settings.check_ip(newhost)
        if newhost!=-1:
            self.HOST=newhost
            return True
        else:
            return False

    def connect(self) -> bool:
        try:
            self.conn.connect((self.HOST,self.PORT))
            self.connected=True
            return True
        except:
            return False
    
    def recv(self) -> list:
        ret=""
        while ret=="":
            ret=self.conn.recv(1024).decode()
            if ret!="":
                ret=ret.split(";")
                ret[1]=ret[1].split(",")
        return ret
    
    def send(self,command:str,details:str) -> bool:
        msg=f"{command};{details}"
        if len(msg)>=1024:
            raise ValueError("Message is too long!")
        try:
            self.conn.sendall(msg.encode())
            return True
        except(ConnectionAbortedError,ConnectionResetError):
            return False

    def want_lord(self,stat:bool) -> bool:
        return self.send("want_lord",stat)

    def play_cards(self,cards:list) -> bool:
        return self.send("play_cards",",".join(cards))
    
    def skip_round(self) -> bool:
        return self.send("skip_round","")

    def send_info(self,settings:Settings) -> bool:
        return self.send("player_info",f"{settings.name},{settings.coin}")
    
    def ready(self) -> bool:
        return self.send("ready","")
    
    def check_alive(self) -> bool:
        return self.send("alive","")



